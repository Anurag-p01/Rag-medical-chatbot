# Chatbot-with-RAG
In this video we talk about how to build a chat app using a large language model. I net out how retrieval augmented generation builds on LLMs, then I show how custom data, like a PDF, can be loaded and used for more meaningful, insightful chat responses.
